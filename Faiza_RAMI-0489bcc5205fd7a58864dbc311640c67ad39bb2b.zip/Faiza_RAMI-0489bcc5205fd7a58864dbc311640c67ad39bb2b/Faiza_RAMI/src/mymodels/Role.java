package mymodels;

public enum Role {
	ETUDIANT,ADMIN,AUTEUR;

}
